//
//  Widget.h
//  WidgetSDK
//
//  Created by Yair Haimovitch on 09/01/2020.
//  Copyright © 2020 WixAnswers. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Widget : NSObject
typedef void (^AuthResultCallback)(NSString*);
typedef void (^AuthCallback)(AuthResultCallback);
typedef void (^OnInitCompleteCallback)(void);
typedef void (^OnNewMessageCallback)(NSString *);
enum ActiveChatStatus {Uninit, NotFound, Found};
typedef void (^OnCompleteHandler)(UIBackgroundFetchResult result);


- (instancetype)init NS_UNAVAILABLE;

+ (void) configureWithTenantName:(NSString*)tenantName
            widgetId:(NSString*)widgetId
            // a callback (that returns void) that receives a callback (that returns void) that accepts a string
            authenticationCallback:(AuthCallback)authenticationCallback
            locale:(NSString*)locale;

+ (void) configureWithTenantName:(NSString*)tenantName
            widgetId:(NSString*)widgetId
            // a callback (that returns void) that receives a callback (that returns void) that accepts a string
            authenticationCallback:(AuthCallback)authenticationCallback;

+ (void)openWidget;

+ (void)setDeviceToken:(NSData *)token;

+ (void)setUserToken:(NSString *)token;

+ (NSString *)getUrl;

+ (AuthCallback)getAuthCallback;

+(void)onInitComplete:(OnInitCompleteCallback)callback;

+(void)onNewMessage:(void (^)(NSString *))callback;

@end

NS_ASSUME_NONNULL_END
