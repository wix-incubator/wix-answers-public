//
//  WidgetSDK.h
//  WidgetSDK
//
//  Created by Yair Haimovitch on 09/01/2020.
//  Copyright © 2020 WixAnswers. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for WidgetSDK.
FOUNDATION_EXPORT double WidgetSDKVersionNumber;

//! Project version string for WidgetSDK.
FOUNDATION_EXPORT const unsigned char WidgetSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <WidgetSDK/PublicHeader.h>

#import <WidgetSDK/Widget.h>
